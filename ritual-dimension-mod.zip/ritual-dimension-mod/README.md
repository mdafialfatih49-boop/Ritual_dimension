# Dimensi Ritual (Minecraft Java 1.20.1, Fabric)

Build: push ke GitHub -> tab Actions -> artifact `ritual-dimension-jar`,
atau lokal: `gradle build` (Gradle 8.5, Java 17) -> `build/libs/ritual-dimension-1.0.0.jar`.
Butuh Fabric API 0.92.2+1.20.1.

## Ritual (Overworld)
1. Taruh 1 blok emas di tanah.
2. Jatuhkan Totem of Undying di atas blok emas (tekan Q).
3. Utara, selatan, timur, barat berjarak 3 blok dari emas: gali tanahnya lalu tutup dengan obsidian.
4. Taruh End Crystal di atas keempat obsidian.
5. Ritual mulai otomatis: 4 sinar ke totem, ~10 detik, lalu portal terbuka di atas emas.
Jarak bisa diubah di `RitualManager.DIST`.
