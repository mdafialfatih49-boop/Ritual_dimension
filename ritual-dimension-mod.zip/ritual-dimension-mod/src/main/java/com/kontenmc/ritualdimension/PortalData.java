package com.kontenmc.ritualdimension;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.PersistentState;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Menyimpan portal asal tiap pemain supaya bisa pulang ke portal yang sama (tersimpan di world). */
public class PortalData extends PersistentState {
    private final Map<UUID, Long> origins = new HashMap<>();

    public static PortalData get(ServerWorld overworld) {
        return overworld.getPersistentStateManager()
                .getOrCreate(PortalData::fromNbt, PortalData::new, "ritualdimension_portals");
    }

    public static PortalData fromNbt(NbtCompound nbt) {
        PortalData d = new PortalData();
        NbtCompound o = nbt.getCompound("origins");
        for (String k : o.getKeys()) {
            try { d.origins.put(UUID.fromString(k), o.getLong(k)); } catch (IllegalArgumentException ignored) {}
        }
        return d;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt) {
        NbtCompound o = new NbtCompound();
        origins.forEach((k, v) -> o.putLong(k.toString(), v));
        nbt.put("origins", o);
        return nbt;
    }

    public void setOrigin(UUID id, BlockPos pos) {
        origins.put(id, pos.asLong());
        markDirty();
    }

    public BlockPos getOrigin(UUID id) {
        Long l = origins.get(id);
        return l == null ? null : BlockPos.fromLong(l);
    }
}
