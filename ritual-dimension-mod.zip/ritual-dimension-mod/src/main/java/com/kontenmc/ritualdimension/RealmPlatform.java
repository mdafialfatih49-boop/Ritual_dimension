package com.kontenmc.ritualdimension;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;

/** Membangun altar kedatangan + portal pulang di Dimensi Ritual (sekitar 0,0). */
public final class RealmPlatform {
    private RealmPlatform() {}

    /** @return posisi berdiri pemain saat tiba. */
    public static BlockPos ensure(ServerWorld realm) {
        int y0 = realm.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, 0, 0);
        BlockPos arrival = new BlockPos(0, y0, 3);
        if (realm.getBlockState(new BlockPos(0, y0, 0)).isOf(RitualDimensionMod.PORTAL)) return arrival;

        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                realm.setBlockState(new BlockPos(dx, y0 - 1, dz), Blocks.OBSIDIAN.getDefaultState(), Block.NOTIFY_LISTENERS);
                for (int dy = 0; dy <= 4; dy++) {
                    realm.setBlockState(new BlockPos(dx, y0 + dy, dz), Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
                }
            }
        }
        realm.setBlockState(new BlockPos(0, y0 - 1, 0), Blocks.GOLD_BLOCK.getDefaultState(), Block.NOTIFY_LISTENERS);

        for (int sx : new int[]{-3, 3}) {
            for (int sz : new int[]{-3, 3}) {
                for (int dy = 0; dy < 3; dy++) {
                    realm.setBlockState(new BlockPos(sx, y0 + dy, sz), Blocks.CRYING_OBSIDIAN.getDefaultState(), Block.NOTIFY_LISTENERS);
                }
                realm.setBlockState(new BlockPos(sx, y0 + 3, sz), Blocks.GLOWSTONE.getDefaultState(), Block.NOTIFY_LISTENERS);
            }
        }
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                if (dx * dx + dz * dz <= 5) {
                    realm.setBlockState(new BlockPos(dx, y0, dz), RitualDimensionMod.PORTAL.getDefaultState(), Block.NOTIFY_LISTENERS);
                }
            }
        }
        return arrival;
    }
}
