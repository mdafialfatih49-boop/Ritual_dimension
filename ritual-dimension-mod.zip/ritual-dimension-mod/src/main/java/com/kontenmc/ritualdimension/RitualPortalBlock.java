package com.kontenmc.ritualdimension;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class RitualPortalBlock extends Block {
    private static final VoxelShape SHAPE = Block.createCuboidShape(0, 0, 0, 16, 4, 16);
    private static final Map<UUID, int[]> TIMERS = new HashMap<>();
    private static final Map<UUID, Integer> COOLDOWN = new HashMap<>();
    private static final int WAIT_TICKS = 50;

    public RitualPortalBlock(Settings settings) {
        super(settings);
    }

    @Override
    public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext ctx) {
        return SHAPE;
    }

    @Override
    public void onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity) {
        if (!(world instanceof ServerWorld sw) || !(entity instanceof ServerPlayerEntity player)) return;
        if (player.hasVehicle() || player.hasPassengers()) return;
        MinecraftServer server = sw.getServer();
        int now = server.getTicks();
        UUID id = player.getUuid();

        Integer cd = COOLDOWN.get(id);
        if (cd != null) {
            if (now < cd) { COOLDOWN.put(id, now + 20); return; }
            COOLDOWN.remove(id);
        }

        int[] t = TIMERS.get(id);
        if (t == null || now - t[1] > 4) {
            t = new int[]{now, now};
            TIMERS.put(id, t);
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 100, 0, false, false, false));
            sw.playSound(null, pos, SoundEvents.BLOCK_PORTAL_TRIGGER, net.minecraft.sound.SoundCategory.BLOCKS, 0.6f, 1.0f);
        } else {
            t[1] = now;
        }
        sw.spawnParticles(ParticleTypes.PORTAL, player.getX(), player.getY() + 1, player.getZ(), 4, 0.3, 0.5, 0.3, 0.3);

        if (now - t[0] >= WAIT_TICKS) {
            TIMERS.remove(id);
            teleport(sw, player, pos, now);
        }
    }

    private static void teleport(ServerWorld from, ServerPlayerEntity player, BlockPos portalPos, int now) {
        MinecraftServer server = from.getServer();
        ServerWorld overworld = server.getOverworld();
        ServerWorld realm = server.getWorld(RitualDimensionMod.REALM);
        if (realm == null) {
            player.sendMessage(Text.literal("Dimensi Ritual belum termuat!"), true);
            return;
        }
        UUID id = player.getUuid();
        COOLDOWN.put(id, now + 40);

        if (from.getRegistryKey() == RitualDimensionMod.REALM) {
            // PULANG ke portal asal
            BlockPos origin = PortalData.get(overworld).getOrigin(id);
            double x, y, z;
            if (origin != null) {
                x = origin.getX() + 0.5; y = origin.getY(); z = origin.getZ() + 0.5;
            } else {
                BlockPos sp = overworld.getSpawnPos();
                x = sp.getX() + 0.5; z = sp.getZ() + 0.5;
                y = overworld.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, sp.getX(), sp.getZ());
            }
            player.teleport(overworld, x, y, z, player.getYaw(), player.getPitch());
            player.fallDistance = 0;
            player.sendMessage(Text.literal("Kamu kembali ke dunia biasa..."), true);
        } else {
            // PERGI ke Dimensi Ritual
            PortalData.get(overworld).setOrigin(id, portalPos);
            BlockPos arrive = RealmPlatform.ensure(realm);
            player.teleport(realm, arrive.getX() + 0.5, arrive.getY(), arrive.getZ() + 0.5, player.getYaw(), player.getPitch());
            player.fallDistance = 0;
            player.sendMessage(Text.literal("Selamat datang di Dimensi Ritual..."), true);
        }
    }

    @Override
    @Environment(EnvType.CLIENT)
    public void randomDisplayTick(BlockState state, World world, BlockPos pos, Random random) {
        if (random.nextInt(3) == 0) {
            world.addParticle(ParticleTypes.PORTAL,
                    pos.getX() + random.nextDouble(), pos.getY() + 0.3, pos.getZ() + random.nextDouble(),
                    0, 0.4, 0);
        }
        if (random.nextInt(40) == 0) {
            world.playSound(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                    SoundEvents.BLOCK_PORTAL_AMBIENT, net.minecraft.sound.SoundCategory.BLOCKS, 0.4f,
                    random.nextFloat() * 0.4f + 0.8f, false);
        }
    }
}
