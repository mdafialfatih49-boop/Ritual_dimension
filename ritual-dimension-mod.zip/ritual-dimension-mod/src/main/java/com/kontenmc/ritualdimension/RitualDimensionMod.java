package com.kontenmc.ritualdimension;

import net.fabricmc.api.ModInitializer;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.block.piston.PistonBehavior;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

public class RitualDimensionMod implements ModInitializer {
    public static final String MOD_ID = "ritualdimension";
    public static final RegistryKey<World> REALM =
            RegistryKey.of(RegistryKeys.WORLD, new Identifier(MOD_ID, "ritual_realm"));
    public static Block PORTAL;

    @Override
    public void onInitialize() {
        PORTAL = Registry.register(Registries.BLOCK, new Identifier(MOD_ID, "ritual_portal"),
                new RitualPortalBlock(AbstractBlock.Settings.create()
                        .mapColor(MapColor.PURPLE)
                        .noCollision()
                        .strength(0.3f)
                        .luminance(s -> 13)
                        .nonOpaque()
                        .sounds(BlockSoundGroup.AMETHYST_BLOCK)
                        .pistonBehavior(PistonBehavior.DESTROY)));
        RitualManager.init();
    }
}
