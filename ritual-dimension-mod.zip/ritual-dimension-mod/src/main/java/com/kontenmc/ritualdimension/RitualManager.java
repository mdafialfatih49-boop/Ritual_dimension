package com.kontenmc.ritualdimension;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.*;

/**
 * Ritual: blok emas di tengah + totem di atasnya, 4 obsidian berjarak DIST blok
 * (utara/selatan/timur/barat) masing-masing dengan end crystal di atasnya.
 */
public final class RitualManager {
    /** Jarak obsidian dari blok emas (hitungan blok, emas = 0). Ubah di sini kalau mau lebih jauh. */
    public static final int DIST = 3;
    /** Lama ritual dalam tick (20 tick = 1 detik). */
    public static final int DURATION = 200;

    private static final Direction[] DIRS = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};
    private static final Map<BlockPos, Ritual> ACTIVE = new HashMap<>();
    private static final Random RNG = new Random();

    private static final class Ritual {
        final ItemEntity totem;
        final List<EndCrystalEntity> crystals;
        int age = 0;
        Ritual(ItemEntity totem, List<EndCrystalEntity> crystals) { this.totem = totem; this.crystals = crystals; }
    }

    private RitualManager() {}

    public static void init() {
        ServerTickEvents.END_WORLD_TICK.register(RitualManager::onTick);
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> ACTIVE.clear());
    }

    private static void onTick(ServerWorld world) {
        if (world.getRegistryKey() != World.OVERWORLD) return;
        tickActive(world);
        if (world.getTime() % 10 == 0) scan(world);
    }

    // ---------- deteksi ----------
    private static List<EndCrystalEntity> findCrystals(ServerWorld w, BlockPos gold) {
        List<EndCrystalEntity> out = new ArrayList<>();
        for (Direction d : DIRS) {
            BlockPos o = gold.offset(d, DIST);
            if (!w.getBlockState(o).isOf(Blocks.OBSIDIAN)) return null;
            Box probe = new Box(o.getX() + 0.4, o.getY() + 1.0, o.getZ() + 0.4,
                                o.getX() + 0.6, o.getY() + 1.5, o.getZ() + 0.6);
            List<EndCrystalEntity> l = w.getEntitiesByClass(EndCrystalEntity.class, probe, c -> !c.isRemoved());
            if (l.isEmpty()) return null;
            out.add(l.get(0));
        }
        return out;
    }

    private static void scan(ServerWorld world) {
        for (ServerPlayerEntity p : world.getPlayers()) {
            List<ItemEntity> items = world.getEntitiesByClass(ItemEntity.class, p.getBoundingBox().expand(24),
                    e -> !e.isRemoved() && e.getStack().isOf(Items.TOTEM_OF_UNDYING));
            for (ItemEntity ie : items) {
                BlockPos gold = BlockPos.ofFloored(ie.getX(), ie.getY() + 0.1, ie.getZ()).down();
                if (ACTIVE.containsKey(gold)) continue;
                if (!world.getBlockState(gold).isOf(Blocks.GOLD_BLOCK)) continue;
                if (!ie.isOnGround()) continue;
                List<EndCrystalEntity> cs = findCrystals(world, gold);
                if (cs == null) continue;
                start(world, gold.toImmutable(), ie, cs);
            }
        }
    }

    private static boolean stillValid(ServerWorld w, BlockPos gold, Ritual r) {
        if (r.totem.isRemoved() || !w.getBlockState(gold).isOf(Blocks.GOLD_BLOCK)) return false;
        for (EndCrystalEntity c : r.crystals) if (c.isRemoved()) return false;
        for (Direction d : DIRS) if (!w.getBlockState(gold.offset(d, DIST)).isOf(Blocks.OBSIDIAN)) return false;
        return true;
    }

    // ---------- jalannya ritual ----------
    private static void start(ServerWorld w, BlockPos gold, ItemEntity totem, List<EndCrystalEntity> cs) {
        Ritual r = new Ritual(totem, cs);
        totem.setNoGravity(true);
        totem.setPickupDelay(32767);
        totem.setInvulnerable(true);
        for (EndCrystalEntity c : cs) c.setBeamTarget(gold.up()); // sinar ke totem
        ACTIVE.put(gold, r);
        w.playSound(null, gold, SoundEvents.BLOCK_END_PORTAL_SPAWN, SoundCategory.BLOCKS, 0.6f, 1.4f);
        broadcast(w, gold, "Ritual dimulai... jangan hancurkan end crystal!", Formatting.GOLD);
    }

    private static void tickActive(ServerWorld w) {
        Iterator<Map.Entry<BlockPos, Ritual>> it = ACTIVE.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<BlockPos, Ritual> e = it.next();
            BlockPos gold = e.getKey();
            Ritual r = e.getValue();
            if (!stillValid(w, gold, r)) {
                cancel(w, gold, r);
                it.remove();
                continue;
            }
            r.age++;
            double p = (double) r.age / DURATION;
            double cx = gold.getX() + 0.5, cz = gold.getZ() + 0.5;
            double y = gold.getY() + 1.0 + p * 1.5;

            r.totem.setPosition(cx, y, cz);
            r.totem.setVelocity(Vec3d.ZERO);
            r.totem.velocityModified = true;

            if (r.age % 20 == 0) for (EndCrystalEntity c : r.crystals) c.setBeamTarget(gold.up());

            // partikel di sepanjang sinar
            Vec3d tp = new Vec3d(cx, y + 0.3, cz);
            for (EndCrystalEntity c : r.crystals) {
                Vec3d cp = new Vec3d(c.getX(), c.getY() + 1.0, c.getZ());
                for (int i = 0; i < 2; i++) {
                    Vec3d v = cp.lerp(tp, RNG.nextDouble());
                    w.spawnParticles(ParticleTypes.END_ROD, v.x, v.y, v.z, 1, 0, 0, 0, 0);
                }
            }
            // pusaran partikel di sekitar totem
            double a = r.age * 0.45;
            double rad = 1.4 - p * 0.8;
            w.spawnParticles(ParticleTypes.PORTAL, cx + Math.cos(a) * rad, y + 0.3, cz + Math.sin(a) * rad, 3, 0.1, 0.1, 0.1, 0.3);
            w.spawnParticles(ParticleTypes.PORTAL, cx + Math.cos(a + Math.PI) * rad, y + 0.3, cz + Math.sin(a + Math.PI) * rad, 3, 0.1, 0.1, 0.1, 0.3);
            if (r.age > DURATION / 2) {
                w.spawnParticles(ParticleTypes.ENCHANT, cx, y + 0.5, cz, 6, 0.6, 0.6, 0.6, 0.5);
            }
            if (r.age % 30 == 1) {
                w.playSound(null, gold, SoundEvents.BLOCK_BEACON_AMBIENT, SoundCategory.BLOCKS, 2.0f, (float) (0.5 + p));
            }

            if (r.age >= DURATION) {
                complete(w, gold, r);
                it.remove();
            }
        }
    }

    private static void cancel(ServerWorld w, BlockPos gold, Ritual r) {
        for (EndCrystalEntity c : r.crystals) if (!c.isRemoved()) c.setBeamTarget(null);
        if (!r.totem.isRemoved()) {
            r.totem.setNoGravity(false);
            r.totem.setPickupDelay(20);
            r.totem.setInvulnerable(false);
        }
        w.playSound(null, gold, SoundEvents.BLOCK_BEACON_DEACTIVATE, SoundCategory.BLOCKS, 2.0f, 1.0f);
        broadcast(w, gold, "Ritual gagal! Susunan rusak.", Formatting.RED);
    }

    private static void complete(ServerWorld w, BlockPos gold, Ritual r) {
        for (EndCrystalEntity c : r.crystals) {
            c.setBeamTarget(null);
            w.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, c.getX(), c.getY() + 1, c.getZ(), 1, 0, 0, 0, 0);
            c.discard();
        }
        r.totem.discard();

        LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(w);
        if (bolt != null) {
            bolt.refreshPositionAfterTeleport(Vec3d.ofBottomCenter(gold.up()));
            bolt.setCosmetic(true);
            w.spawnEntity(bolt);
        }
        w.playSound(null, gold, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 3.0f, 0.8f);
        w.playSound(null, gold, SoundEvents.ENTITY_ENDER_DRAGON_GROWL, SoundCategory.BLOCKS, 3.0f, 0.7f);

        // portal: cakram datar di atas blok emas
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                if (dx * dx + dz * dz > 5) continue;
                BlockPos pos = gold.add(dx, 1, dz);
                BlockState s = w.getBlockState(pos);
                boolean center = dx == 0 && dz == 0;
                if (center || s.isAir() || s.isReplaceable()) {
                    w.setBlockState(pos, RitualDimensionMod.PORTAL.getDefaultState(), Block.NOTIFY_ALL);
                }
            }
        }
        w.spawnParticles(ParticleTypes.END_ROD, gold.getX() + 0.5, gold.getY() + 1.5, gold.getZ() + 0.5, 80, 1.5, 0.8, 1.5, 0.15);
        broadcast(w, gold, "Portal Dimensi Ritual terbuka!", Formatting.LIGHT_PURPLE);
    }

    private static void broadcast(ServerWorld w, BlockPos at, String msg, Formatting color) {
        Vec3d c = Vec3d.ofCenter(at);
        for (ServerPlayerEntity p : w.getPlayers()) {
            if (p.squaredDistanceTo(c) < 48 * 48) p.sendMessage(Text.literal(msg).formatted(color), true);
        }
    }
}
